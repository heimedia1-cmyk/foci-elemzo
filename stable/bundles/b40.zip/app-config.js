// Android app: helyi játékfájlok, online funkciók a Railway-szerveren.
window.MEXI_API_BASE = "https://mexiverse.up.railway.app";
window.MEXI_APP = true;
window.MEXI_BUILD = "1.0.0 (2026-11-18)";
window.MEXI_BUILD_ID = "b40";
window.MEXI_NATIVE = 2;
window.MEXI_CHANNEL = "stable";
