// MexiVerse – belépési pont.
import { BootScene } from './scenes/BootScene.js';
import { TitleScene } from './scenes/TitleScene.js';
import { WorldScene } from './scenes/WorldScene.js';
import { BattleScene } from './scenes/BattleScene.js';
import { CoopBattleScene } from './scenes/CoopBattleScene.js';

const isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
window.MEXI_TOUCH = isTouch;

const game = new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  backgroundColor: '#1b1430',
  pixelArt: true,
  roundPixels: true,
  antialias: false,
  powerPreference: 'high-performance',
  fps: { target: 60, min: 20, smoothStep: true },
  input: { activePointers: 3 },
  scale: { mode: Phaser.Scale.RESIZE, width: window.innerWidth, height: window.innerHeight },
  scene: [BootScene, TitleScene, WorldScene, BattleScene, CoopBattleScene],
});
window.MEXI_GAME = game;
import { initNative } from './systems/native.js';
initNative(game);
import { initLiveUpdate } from './systems/liveUpdate.js';
initLiveUpdate(game);

// Mobilon a böngésző görgetése ne zavarjon
document.addEventListener('gesturestart', (e) => e.preventDefault());
// hosszú nyomásra ne jöjjön böngészős helyi menü, dupla koppintásra ne nagyítson
document.addEventListener('contextmenu', (e) => { if (!(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)) e.preventDefault(); });
document.addEventListener('dblclick', (e) => e.preventDefault(), { passive: false });

// Fejlesztői segédlet (konzolból / automata tesztekhez)
import { G } from './systems/state.js';
window.MEXI_DEBUG = { G, game };

import { toast } from './ui/ui.js';
window.addEventListener('mexi-auth-expired', () => toast('Lejárt a belépésed – a mentés csak ezen az eszközön van. Lépj be újra a főmenüben.', 5000));
